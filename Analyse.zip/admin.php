<?php
// admin.php (mit integriertem Header-Debug-Test)

// --- Debug-Ausgabe aktivieren ---
ob_start(); // Alles, was bisher ausgegeben wird, wird in einem Buffer gesammelt

// --- Prüfen, ob bereits Header gesendet wurden ---
if (headers_sent($file, $line)) {
    die("‼️ Fehler: Header wurden bereits gesendet in $file auf Zeile $line");
}

// --- Session starten ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$menu_dir = __DIR__ . '/menu/'; // Ordner für die Menüpunkte

// Nur eingeloggte Admins haben Zugriff
if (!isset($_SESSION['logged_in']) || !$_SESSION['logged_in']) {
    // Prüfen, ob Header bereits gesendet wurden
    if (headers_sent($file, $line)) {
        die("‼️ Fehler: Header wurden bereits gesendet in $file auf Zeile $line");
    }

    header("Location: menu/login.php");
    exit;
}

// Menüpunkt laden
$page = preg_replace('/[^a-z_]/', '', $_GET['page'] ?? 'dashboard');
$allowed_pages = ['dashboard', 'categories', 'add_link', 'manage_links', 'settings', 'manage_users', 'logout'];

// Sicherheitsüberprüfung des Seitenwertes
if (!in_array($page, $allowed_pages)) {
    $page = 'dashboard';
}

// Sonderfall: Logout
if ($page === 'logout') {
    include_once $menu_dir . 'logout.php';
    exit;
}

// Vorbereiten des einzubindenden Menüpunkts
$file_to_include = $menu_dir . $page . '.php';
if (!file_exists($file_to_include)) {
    error_log("Fehler: Datei '$file_to_include' nicht gefunden.", 0);
    $file_to_include = null;
}

// --- DEBUG: Ausgabe testen ---
$output = ob_get_clean(); // Alles bis hierher gepuffert
if (headers_sent($file, $line)) {
    echo "‼️ Header bereits gesendet in $file auf Zeile $line<br>";
}
if (!empty($output)) {
    echo "⚠️ Es wurde folgende Ausgabe bereits erzeugt:<br><pre>" . htmlspecialchars($output) . "</pre>";
} else {
    ob_start(); // Buffer neu starten für HTML-Ausgabe
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Adminbereich</title>
    <link rel="stylesheet" href="styles-admin.css">
</head>
<body>
<div class="admin-container">
    <aside class="sidebar">
        <h2>Admin-Menü</h2>
        <ul>
            <li><a href="?page=dashboard">Dashboard</a></li>
            <li><a href="?page=categories">Kategorien verwalten</a></li>
            <li><a href="?page=add_link">Neuen Link hinzufügen</a></li>
            <li><a href="?page=manage_links">Links verwalten</a></li>
            <li><a href="?page=settings">Logo & Favicon ändern</a></li>
            <li><a href="?page=manage_users">Benutzer verwalten</a></li>
            <li><a href="?page=logout">Abmelden</a></li>
        </ul>
        <div class="online-help-container">
            <a href="https://onlinehelp.igm-ch.ch/" class="online-help-link">Zur Onlinehilfe</a>
        </div>
    </aside>
    <main class="main-content">
        <?php
        if ($file_to_include) {
            include $file_to_include;
        } else {
            echo "<h1>Seite nicht gefunden</h1>";
        }
        ?>
    </main>
</div>
</body>
</html>
