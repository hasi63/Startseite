<?php
// /index.php

// Links und Kategorien laden
$links = file_exists('data/links.json') ? json_decode(file_get_contents('data/links.json'), true) : [];
$categories = file_exists('data/categories.json') ? json_decode(file_get_contents('data/categories.json'), true) : [];

// Gruppiere Links nach Kategorien
$grouped = [];
foreach ($categories as $cat) {
    $grouped[$cat] = array_filter($links, fn($l) => $l['category'] === $cat);
}

// Logo und Favicon-Pfade
$logo_path = file_exists('uploads/logo.png') ? 'uploads/logo.png' : 'https://www.facebook.com/photo/?fbid=395525879436502&set=a.395525832769840&__tn__=%3C';
$favicon_path = file_exists('uploads/favicon.ico') ? 'uploads/favicon.ico' : '';
?>
<!DOCTYPE html>
<html lang="de">
<head>
  <meta charset="UTF-8">
  <title>IGM Onlinehilfe</title>
  <?php if ($favicon_path): ?>
    <link rel="icon" href="<?= $favicon_path ?>" type="image/x-icon">
  <?php endif; ?>
  <link rel="stylesheet" href="styles-main.css">
</head>
<body>
<div class="container">
  <header class="header">
    <img src="<?= htmlspecialchars($logo_path, ENT_QUOTES, 'UTF-8') ?>" alt="Logo" class="logo">
    <h1>IGM Onlinehilfe</h1>
  </header>
  <p><a href="admin.php" class="admin-link">Zum Adminbereich</a></p>

  <div class="block-container">
    <?php foreach ($grouped as $cat => $catLinks): ?>
      <?php if (!empty($catLinks)): ?>
        <div class="block">
          <h2 class="category-title"><?= htmlspecialchars($cat, ENT_QUOTES, 'UTF-8') ?></h2>
          <ul class="link-list">
            <?php foreach ($catLinks as $link): ?>
              <li><a href="<?= htmlspecialchars($link['url'], ENT_QUOTES, 'UTF-8') ?>" target="_blank" class="link-item"><?= htmlspecialchars($link['title'], ENT_QUOTES, 'UTF-8') ?></a></li>
            <?php endforeach; ?>
          </ul>
        </div>
      <?php endif; ?>
    <?php endforeach; ?>
  </div>
</div>
</body>
</html>