<?php
// /menu/add_link.php

// --- Fehleranzeige aktivieren (nur in Entwicklung!) ---
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- Pfade definieren ---
$data_links = __DIR__ . '/../data/links.json';
$data_categories = __DIR__ . '/../data/categories.json';

// --- Kategorien laden ---
$categories = [];
if (file_exists($data_categories)) {
    $categories = json_decode(file_get_contents($data_categories), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die('❌ Fehler beim Lesen von categories.json: ' . json_last_error_msg());
    }
}
if (!is_array($categories)) {
    die('❌ Kategorien-Daten ungültig oder leer.');
}

// --- Links laden ---
$links = [];
if (file_exists($data_links)) {
    $links = json_decode(file_get_contents($data_links), true);
    if (json_last_error() !== JSON_ERROR_NONE) {
        die('❌ Fehler beim Lesen von links.json: ' . json_last_error_msg());
    }
}
if (!is_array($links)) {
    $links = []; // Notfall: Leeres Array anlegen
}

// --- Link hinzufügen ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['title'], $_POST['url'], $_POST['category'])) {
    $new_link = [
        'title' => trim($_POST['title']),
        'url' => trim($_POST['url']),
        'category' => trim($_POST['category']),
    ];

    // --- Validierung ---
    if (!empty($new_link['title']) && !empty($new_link['url']) && !empty($new_link['category'])) {
        $links[] = $new_link;
        $result = file_put_contents($data_links, json_encode($links, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        if ($result === false) {
            die('❌ Fehler beim Schreiben der Datei links.json (Schreibrechte prüfen)');
        }

        // --- Weiterleitung ---
        if (!headers_sent($f, $l)) {
            header("Location: admin.php?page=add_link");
            exit;
        } else {
            die("‼ Header bereits gesendet in $f auf Zeile $l – Weiterleitung fehlgeschlagen.");
        }
    } else {
        echo "<p class='error-message'>❌ Alle Felder müssen ausgefüllt sein.</p>";
    }
}
?>

<h1>🔗 Neuer Link hinzufügen</h1>
<form method="post">
    <label for="title">Titel:</label>
    <input type="text" name="title" id="title" required>

    <label for="url">URL:</label>
    <input type="text" name="url" id="url" required>

    <label for="category">Kategorie:</label>
    <select name="category" id="category" required>
        <?php foreach ($categories as $category): ?>
            <option value="<?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>">
                <?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>
            </option>
        <?php endforeach; ?>
    </select>

    <input type="submit" value="Hinzufügen">
</form>