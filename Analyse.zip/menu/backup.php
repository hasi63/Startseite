<?php
// /menu/backup.php

session_start();
if (!isset($_SESSION['is_admin']) || $_SESSION['is_admin'] !== true) {
    die('Zugriff verweigert.');
}

$backup_dir = __DIR__ . '/../backup/';
if (!is_dir($backup_dir)) {
    mkdir($backup_dir, 0777, true); // Backup-Verzeichnis erstellen, falls es nicht existiert
}

$backupFiles = array_diff(scandir($backup_dir), array('.', '..')); // Verzeichnisinhalt holen
usort($backupFiles, function($a, $b) use ($backup_dir) {
    return filemtime($backup_dir . $b) - filemtime($backup_dir . $a); // Sortierung nach Datum
});

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create_backup'])) {
        // Backup erstellen
        $timestamp = date('Ymd_His');
        $backupFile = $backup_dir . "backup_{$timestamp}.zip"; // Zip-Datei mit Zeitstempel
        $zip = new ZipArchive();
        if ($zip->open($backupFile, ZipArchive::CREATE) === TRUE) {
            // Verzeichnisinhalt hinzufügen
            $dirIterator = new RecursiveDirectoryIterator(__DIR__ . '/../');
            $iterator = new RecursiveIteratorIterator($dirIterator);
            foreach ($iterator as $file) {
                if ($file->isFile()) {
                    $zip->addFile($file, $file->getFilename());
                }
            }
            $zip->close();
            echo '<p>Backup erfolgreich erstellt: ' . htmlspecialchars($backupFile) . '</p>';
        } else {
            echo '<p>Fehler beim Erstellen des Backups.</p>';
        }
    } elseif (isset($_POST['delete'])) {
        $deleteFile = $backup_dir . $_POST['delete'];
        if (file_exists($deleteFile)) {
            unlink($deleteFile); // Löschen
        } else {
            echo "<p>Fehler: Die Datei existiert nicht.</p>";
        }
    } elseif (isset($_POST['rename']) && isset($_POST['new_name'])) {
        $oldFile = $backup_dir . $_POST['rename'];
        $newFile = $backup_dir . $_POST['new_name'];
        if (file_exists($oldFile)) {
            rename($oldFile, $newFile); // Umbenennen
        } else {
            echo "<p>Fehler: Die Datei konnte nicht umbenannt werden.</p>";
        }
    }
}
?>

<h1>Backup-Übersicht</h1>

<form method="post">
    <button type="submit" name="create_backup" class="button">Neues Backup erstellen</button>
</form>

<h2>Vorhandene Backups</h2>
<table>
    <thead>
        <tr>
            <th>Dateiname</th>
            <th>Aktionen</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($backupFiles as $backupFile): ?>
            <tr>
                <td><?= htmlspecialchars($backupFile) ?></td>
                <td>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="delete" value="<?= htmlspecialchars($backupFile) ?>">
                        <button type="submit" onclick="return confirm('Möchten Sie dieses Backup wirklich löschen?');">Löschen</button>
                    </form>
                    <form method="post" style="display:inline;">
                        <input type="hidden" name="rename" value="<?= htmlspecialchars($backupFile) ?>">
                        <input type="text" name="new_name" placeholder="Neuer Name" required>
                        <button type="submit">Umbenennen</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
