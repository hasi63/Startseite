<?php
// /menu/categories.php

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Funktion, um Änderungen in die JSON-Datei zu schreiben
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);
        if (!is_array($currentData)) {
            $currentData = []; // Fallback bei fehlerhaftem JSON
        }
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;

    // JSON-Daten zurück in die Datei schreiben
    if (file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT)) === false) {
        error_log("Fehler beim Schreiben in die Datei: $filePath");
    }
}

// Pfade zu den JSON-Dateien
$data_categories = __DIR__ . '/../data/categories.json';
$changeLogPath = __DIR__ . '/../data/change_log.json';

// Kategorien laden
$categories = [];
if (file_exists($data_categories)) {
    $jsonData = file_get_contents($data_categories);
    $categories = json_decode($jsonData, true);
    if (!is_array($categories)) {
        $categories = []; // Fallback bei fehlerhaftem JSON
    }
}

// Neue Kategorie hinzufügen
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_category'])) {
    $new_category = trim($_POST['new_category']);
    if (!empty($new_category) && !in_array($new_category, $categories, true)) {
        $categories[] = $new_category;

        // Kategorien speichern
        if (file_put_contents($data_categories, json_encode($categories, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false) {
            logChange($changeLogPath, "Kategorie hinzugefügt: $new_category", $_SESSION['username'] ?? 'unbekannt');
        }
    }
    if (headers_sent($file, $line)) {
        die("Headers bereits gesendet in $file auf Zeile $line");
    }
    header("Location: admin.php?page=categories");
    exit;
}

// Kategorie löschen
if (isset($_GET['delete_category'])) {
    $index = (int)$_GET['delete_category'];
    if (isset($categories[$index])) {
        $deleted_category = $categories[$index];
        array_splice($categories, $index, 1);

        // Kategorien speichern
        if (file_put_contents($data_categories, json_encode($categories, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)) !== false) {
            logChange($changeLogPath, "Kategorie gelöscht: $deleted_category", $_SESSION['username'] ?? 'unbekannt');
        }
    }
    if (headers_sent($file, $line)) {
        die("Headers bereits gesendet in $file auf Zeile $line");
    }
    header("Location: admin.php?page=categories");
    exit;
}

// Kategorie verschieben (Umsortieren)
if (isset($_GET['move_category']) && isset($_GET['index'])) {
    $index = (int)$_GET['index'];
    if ($_GET['move_category'] === 'up' && $index > 0) {
        // Kategorie nach oben verschieben
        [$categories[$index - 1], $categories[$index]] = [$categories[$index], $categories[$index - 1]];

        // Änderung protokollieren
        logChange($changeLogPath, "Kategorie verschoben: {$categories[$index]} nach oben", $_SESSION['username'] ?? 'unbekannt');
    } elseif ($_GET['move_category'] === 'down' && $index < count($categories) - 1) {
        // Kategorie nach unten verschieben
        [$categories[$index + 1], $categories[$index]] = [$categories[$index], $categories[$index + 1]];

        // Änderung protokollieren
        logChange($changeLogPath, "Kategorie verschoben: {$categories[$index]} nach unten", $_SESSION['username'] ?? 'unbekannt');
    }

    // Kategorien speichern
    file_put_contents($data_categories, json_encode($categories, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    if (headers_sent($file, $line)) {
        die("Headers bereits gesendet in $file auf Zeile $line");
    }
    header("Location: admin.php?page=categories");
    exit;
}
?>
<h1>🗂 Kategorien verwalten</h1>
<form method="post">
    <label>Neue Kategorie: <input type="text" name="new_category" required></label>
    <input type="submit" value="Hinzufügen">
</form>
<ul>
    <?php foreach ($categories as $i => $category): ?>
        <li>
            <?= htmlspecialchars($category, ENT_QUOTES, 'UTF-8') ?>
            <a href="?page=categories&move_category=up&index=<?= $i ?>">🔼</a>
            <a href="?page=categories&move_category=down&index=<?= $i ?>">🔽</a>
            <a href="?page=categories&delete_category=<?= $i ?>" onclick="return confirm('Kategorie wirklich löschen?')">❌</a>
        </li>
    <?php endforeach; ?>
</ul>