<?php
// Debugging: Prüfen, ob Header bereits gesendet wurden
if (headers_sent($file, $line)) {
    die("Headers bereits gesendet in $file auf Zeile $line");
}

session_start();

// Pfade zu den JSON-Dateien
$changeLogPath = __DIR__ . '/../data/change_log.json';
$adminsPath = __DIR__ . '/../data/admins.json';

// Funktion, um die letzten Änderungen aus der JSON-Datei zu laden
function fetchRecentChanges($filePath, $limit = 5) {
    if (!file_exists($filePath)) {
        return []; // Leere Liste, falls die Datei nicht existiert
    }

    $jsonData = file_get_contents($filePath);
    $changes = json_decode($jsonData, true);

    if ($changes === null || !is_array($changes)) {
        error_log("Ungültige JSON-Daten in $filePath");
        return [];
    }

    usort($changes, function ($a, $b) {
        return strtotime($b['change_date']) - strtotime($a['change_date']);
    });

    return array_slice($changes, 0, $limit);
}

// Funktion, um die zuletzt angemeldeten Admins aus der JSON-Datei zu laden
function fetchRecentLogins($filePath, $limit = 5) {
    if (!file_exists($filePath)) {
        return [];
    }

    $jsonData = file_get_contents($filePath);
    $admins = json_decode($jsonData, true);

    if ($admins === null || !is_array($admins)) {
        error_log("Fehler beim Dekodieren der JSON-Datei: $filePath");
        return [];
    }

    usort($admins, function ($a, $b) {
        return strtotime($b['last_login'] ?? '1970-01-01 00:00:00') - strtotime($a['last_login'] ?? '1970-01-01 00:00:00');
    });

    return array_slice($admins, 0, $limit);
}

// Abrufen der Daten
$recentChanges = fetchRecentChanges($changeLogPath);
$recentLogins = fetchRecentLogins($adminsPath);

// Debugging: Prüfen, ob Header bereits gesendet wurden
if (headers_sent($file, $line)) {
    die("Headers bereits gesendet in $file auf Zeile $line");
}
?>

<h1>Willkommen im Admin-Dashboard!</h1>
<p>Verwalten Sie Kategorien, Links und Einstellungen über das Menü.</p>

<h2>Letzte Änderungen</h2>
<table border="1">
    <thead>
        <tr>
            <th>Datum</th>
            <th>Beschreibung</th>
            <th>Benutzer</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($recentChanges)): ?>
            <tr>
                <td colspan="3">Keine Änderungen verfügbar.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($recentChanges as $change): ?>
                <tr>
                    <td><?= htmlspecialchars($change['change_date']) ?></td>
                    <td><?= htmlspecialchars($change['description']) ?></td>
                    <td><?= htmlspecialchars($change['username']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>

<h2>Zuletzt angemeldete Admins</h2>
<table border="1">
    <thead>
        <tr>
            <th>Benutzername</th>
            <th>Letzte Anmeldung</th>
        </tr>
    </thead>
    <tbody>
        <?php if (empty($recentLogins)): ?>
            <tr>
                <td colspan="2">Keine Anmeldungen verfügbar.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($recentLogins as $login): ?>
                <tr>
                    <td><?= htmlspecialchars($login['username']) ?></td>
                    <td><?= htmlspecialchars($login['last_login']) ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
    </tbody>
</table>