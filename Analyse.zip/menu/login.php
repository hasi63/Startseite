<?php
// /menu/login.php

// Debugging: Prüfen, ob Header bereits gesendet wurden
if (headers_sent($file, $line)) {
    die("Headers bereits gesendet in $file auf Zeile $line");
}

session_start();

$data_admins = __DIR__ . '/../data/admins.json'; // Pfad zur Admin-Daten-Datei
$changeLogPath = __DIR__ . '/../data/change_log.json'; // Pfad zur Änderungsprotokoll-Datei

// Funktion: Admin-Daten laden
function load_admins($path) {
    if (file_exists($path)) {
        return json_decode(file_get_contents($path), true);
    }
    return [];
}

// Funktion: Admin-Authentifizierung prüfen
function authenticate_admin($username, $password, $admins) {
    foreach ($admins as $admin) {
        if ($admin['username'] === $username && password_verify($password, $admin['password'])) {
            return true; // Login erfolgreich
        }
    }
    return false; // Login fehlgeschlagen
}

// Funktion: Passwort zurücksetzen und per E-Mail senden
function reset_password($email, $admins, $path) {
    foreach ($admins as &$admin) {
        if ($admin['email'] === $email) {
            $new_password = bin2hex(random_bytes(4)); // Zufälliges 8-stelliges Passwort
            $admin['password'] = password_hash($new_password, PASSWORD_DEFAULT); // Passwort hashen
            file_put_contents($path, json_encode($admins, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));

            // E-Mail senden (vereinfachte Version)
            $subject = "Passwort zurücksetzen";
            $message = "Ihr neues Passwort lautet: $new_password\nBitte ändern Sie es nach der Anmeldung.";
            $headers = "From: admin@yourdomain.com";

            mail($email, $subject, $message, $headers);
            return true;
        }
    }
    return false;
}

// Funktion, um Änderungen in die JSON-Datei zu schreiben
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;

    file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT));
}

// Admin-Daten laden
$admins = load_admins($data_admins);

// Login-Logik
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['password'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (authenticate_admin($username, $password, $admins)) {
        $_SESSION['logged_in'] = true;
        $_SESSION['username'] = $username;

        // Änderung protokollieren
        logChange($changeLogPath, "Admin $username hat sich eingeloggt", $username);

        // Debugging: Prüfen, ob Header gesendet wurde
        if (headers_sent($file, $line)) {
            die("Headers bereits gesendet in $file auf Zeile $line");
        }

        header("Location: ../admin.php");
        exit;
    } else {
        $login_error = "Falscher Benutzername oder Passwort.";
    }
}

// Passwort-Wiederherstellung
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email'])) {
    $email = trim($_POST['email']);
    if (reset_password($email, $admins, $data_admins)) {
        $reset_success = "Ein neues Passwort wurde an Ihre E-Mail-Adresse gesendet.";

        // Änderung protokollieren
        logChange($changeLogPath, "Passwort wurde für die E-Mail $email zurückgesetzt", "System");
    } else {
        $reset_error = "Die E-Mail-Adresse wurde nicht gefunden.";
    }
}

// Logout-Logik
if (isset($_GET['logout'])) {
    if (isset($_SESSION['username'])) {
        logChange($changeLogPath, "Admin {$_SESSION['username']} hat sich ausgeloggt", $_SESSION['username']);
    }
    session_destroy();

    // Debugging: Prüfen, ob Header gesendet wurde
    if (headers_sent($file, $line)) {
        die("Headers bereits gesendet in $file auf Zeile $line");
    }

    header("Location: login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <link rel="stylesheet" href="../styles-admin.css">
</head>
<body>
<div class="login-container">
    <main class="login-content">
        <h1>Login</h1>
        <?php if (isset($login_error)): ?>
            <p class="error-message"><?= htmlspecialchars($login_error, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
        <?php if (isset($reset_success)): ?>
            <p class="success"><?= htmlspecialchars($reset_success, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
        <?php if (isset($reset_error)): ?>
            <p class="error-message"><?= htmlspecialchars($reset_error, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>
        <form method="post" class="login-form">
            <label for="username">Benutzername:</label>
            <input type="text" name="username" id="username" required>
            <label for="password">Passwort:</label>
            <input type="password" name="password" id="password" required>
            <input type="submit" value="Einloggen">
        </form>
        <p><a href="#" onclick="document.getElementById('reset-password-form').style.display = 'block'; return false;">Passwort vergessen?</a></p>
        <form method="post" id="reset-password-form" style="display: none;">
            <label for="email">E-Mail-Adresse:</label>
            <input type="email" name="email" id="email" required>
            <input type="submit" value="Passwort zurücksetzen">
        </form>
    </main>
</div>
</body>
</html>
