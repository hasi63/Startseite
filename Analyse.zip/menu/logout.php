<?php
// /menu/logout.php

// Prüfen, ob Header bereits gesendet wurden
if (headers_sent($file, $line)) {
    die("Headers bereits gesendet in $file auf Zeile $line");
}

// Session starten
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Funktion: Änderungsprotokoll speichern
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Fehler in JSON-Datei: " . json_last_error_msg());
            $currentData = []; // Fallback bei fehlerhaftem JSON
        }
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;

    if (file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT)) === false) {
        error_log("Fehler beim Schreiben in die Datei: $filePath");
    }
}

// Änderungsprotokoll speichern
$changeLogPath = __DIR__ . '/../data/change_log.json';
if (isset($_SESSION['username'])) {
    logChange($changeLogPath, 'Admin ' . $_SESSION['username'] . ' hat sich ausgeloggt', $_SESSION['username']);
}

// Session zerstören
session_destroy();

// Weiterleitung zur Login-Seite, sicherstellen, dass kein Output vorab gesendet wurde
header("Location: /menu/login.php");
exit;
