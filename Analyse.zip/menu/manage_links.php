<?php
// manage_links.php

$data_links = __DIR__ . '/../data/links.json';
$data_categories = __DIR__ . '/../data/categories.json';
$changeLogPath = __DIR__ . '/../data/change_log.json';

$categories = file_exists($data_categories) ? json_decode(file_get_contents($data_categories), true) : [];
$links = file_exists($data_links) ? json_decode(file_get_contents($data_links), true) : [];

// Funktion zum Protokollieren
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Fehler in JSON-Datei: " . json_last_error_msg());
            $currentData = [];
        }
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;
    file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT));
}

// Links verschieben
if (isset($_GET['move_link'])) {
    $index = (int)$_GET['move_link'];
    $direction = $_GET['direction']; // 'up' oder 'down'
    if (isset($links[$index])) {
        // Verschieben innerhalb der gleichen Kategorie
        $category = $links[$index]['category'];
        $category_links = [];
        foreach ($links as $key => $link) {
            if ($link['category'] === $category) {
                $category_links[] = $key;
            }
        }

        $key_pos = array_search($index, $category_links);
        if ($key_pos !== false) {
            if ($direction === 'up' && $key_pos > 0) {
                // Verschieben nach oben
                $tmp = $links[$category_links[$key_pos]];
                $links[$category_links[$key_pos]] = $links[$category_links[$key_pos - 1]];
                $links[$category_links[$key_pos - 1]] = $tmp;
            } elseif ($direction === 'down' && $key_pos < count($category_links) - 1) {
                // Verschieben nach unten
                $tmp = $links[$category_links[$key_pos]];
                $links[$category_links[$key_pos]] = $links[$category_links[$key_pos + 1]];
                $links[$category_links[$key_pos + 1]] = $tmp;
            }
            file_put_contents($data_links, json_encode($links, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
            logChange($changeLogPath, "Link verschoben: {$links[$index]['title']}", $_SESSION['username'] ?? 'unbekannt');
        }
    }
    header("Location: admin.php?page=manage_links");
    exit;
}

// Hinzufügen und Löschen wie zuvor
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_link'])) {
    $new_link = [
        'title' => trim($_POST['title']),
        'url' => trim($_POST['url']),
        'category' => trim($_POST['category']),
    ];
    if (!empty($new_link['title']) && !empty($new_link['url']) && !empty($new_link['category'])) {
        $links[] = $new_link;
        file_put_contents($data_links, json_encode($links, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        logChange($changeLogPath, "Link hinzugefügt: {$new_link['title']}", $_SESSION['username'] ?? 'unbekannt');
    }
    header("Location: admin.php?page=manage_links");
    exit;
}

if (isset($_GET['delete_link'])) {
    $index = (int)$_GET['delete_link'];
    if (isset($links[$index])) {
        $deleted_link = $links[$index];
        array_splice($links, $index, 1);
        file_put_contents($data_links, json_encode($links, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        logChange($changeLogPath, "Link gelöscht: {$deleted_link['title']}", $_SESSION['username'] ?? 'unbekannt');
    }
    header("Location: admin.php?page=manage_links");
    exit;
}
?>

<h1>🔗 Links verwalten (gruppiert nach Kategorie)</h1>

<?php
// Gruppieren der Links nach Kategorie
$grouped = [];
foreach ($links as $index => $link) {
    $grouped[$link['category']][] = ['data' => $link, 'index' => $index];
}

if (empty($grouped)) {
    echo "<p>❕ Noch keine Links vorhanden.</p>";
} else {
    foreach ($grouped as $category => $linkSet):
?>
    <h2><?= htmlspecialchars($category) ?></h2>
    <table>
        <thead>
        <tr>
            <th>Titel</th>
            <th>URL</th>
            <th>Aktionen</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($linkSet as $entry): 
            $link = $entry['data'];
            $index = $entry['index'];
        ?>
            <tr>
                <form method="post">
                    <td>
                        <input type="text" name="title" value="<?= htmlspecialchars($link['title']) ?>" required>
                    </td>
                    <td>
                        <input type="text" name="url" value="<?= htmlspecialchars($link['url']) ?>" required>
                    </td>
                    <td>
                        <input type="hidden" name="index" value="<?= $index ?>">
                        <select name="category" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= htmlspecialchars($cat) ?>" <?= $cat === $link['category'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($cat) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" name="edit_link">💾 Speichern</button>
                        <a href="?page=manage_links&delete_link=<?= $index ?>" onclick="return confirm('Diesen Link wirklich löschen?')">🗑️</a>
                        <!-- Verschiebe-Pfeile -->
                        <a href="?page=manage_links&move_link=<?= $index ?>&direction=up" title="Nach oben verschieben">🔼</a>
                        <a href="?page=manage_links&move_link=<?= $index ?>&direction=down" title="Nach unten verschieben">🔽</a>
                    </td>
                </form>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
<?php
    endforeach;
}
?>
