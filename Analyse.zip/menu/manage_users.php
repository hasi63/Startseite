<?php
// /menu/manage_users.php

// Fehlerprotokollierung aktivieren
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// --- Debug-Ausgabe aktivieren ---
ob_start(); // Alles, was bisher ausgegeben wird, wird in einem Buffer gesammelt

// Datenpfad
$data_admins = __DIR__ . '/../data/admins.json';
$changeLogPath = __DIR__ . '/../data/change_log.json';

// Funktion: Admin-Daten laden
function load_admins($path) {
    if (file_exists($path)) {
        return json_decode(file_get_contents($path), true);
    }
    return [];
}

// Funktion: Admin-Daten speichern
function save_admins($path, $admins) {
    file_put_contents($path, json_encode($admins, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
}

// Funktion: Zufälliges Passwort generieren (mindestens 128 Bit / 16 Bytes)
function generate_random_password() {
    $characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_=+[]{}|;:,.<>?/~`';
    $passwordLength = 16; // Passwortlänge, z.B. 16 Zeichen
    $randomPassword = '';

    for ($i = 0; $i < $passwordLength; $i++) {
        $randomPassword .= $characters[random_int(0, strlen($characters) - 1)];
    }

    return $randomPassword;
}

// Funktion: Änderungsprotokoll speichern
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;

    if (file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT)) === false) {
        error_log("Fehler beim Schreiben in die Datei: $filePath");
    }
}

// Benutzer laden
$admins = load_admins($data_admins);

// Benutzer hinzufügen
if (isset($_POST['add_user'])) {
    $new_username = $_POST['new_username'];
    $new_firstname = $_POST['new_firstname'];
    $new_lastname = $_POST['new_lastname'];
    $new_email = $_POST['new_email'];
    $new_password = $_POST['new_password'] ?: generate_random_password(); // Passwort wird generiert, wenn leer

    $new_user = [
        'username' => $new_username,
        'firstname' => $new_firstname,
        'lastname' => $new_lastname,
        'email' => $new_email,
        'password' => password_hash($new_password, PASSWORD_DEFAULT),
    ];

    $admins[] = $new_user;
    save_admins($data_admins, $admins);

    logChange($changeLogPath, "Benutzer hinzugefügt: $new_username", $_SESSION['username'] ?? 'unbekannt');

    $success_message = "Benutzer wurde erfolgreich hinzugefügt.";
}

// Benutzer löschen
if (isset($_GET['delete_user'])) {
    $index = (int)$_GET['delete_user'];
    if (isset($admins[$index])) {
        $deleted_user = $admins[$index]['username'];
        array_splice($admins, $index, 1);
        save_admins($data_admins, $admins);

        logChange($changeLogPath, "Benutzer gelöscht: $deleted_user", $_SESSION['username'] ?? 'unbekannt');

        header("Location: admin.php?page=manage_users");
        exit;
    }
}

// Benutzer bearbeiten
if (isset($_GET['edit_user'])) {
    $index = (int)$_GET['edit_user'];
    if (isset($admins[$index])) {
        $edit_user = $admins[$index];

        // Wenn das Formular abgeschickt wird
        if (isset($_POST['edit_user'])) {
            // Überprüfen, ob neue Daten vorhanden sind
            $admins[$index]['username'] = $_POST['new_username'];
            $admins[$index]['firstname'] = $_POST['new_firstname'];
            $admins[$index]['lastname'] = $_POST['new_lastname'];
            $admins[$index]['email'] = $_POST['new_email'];
            
            // Passwort nur ändern, wenn eingegeben
            if (!empty($_POST['new_password'])) {
                $admins[$index]['password'] = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            }

            save_admins($data_admins, $admins);
            logChange($changeLogPath, "Benutzer bearbeitet: {$admins[$index]['username']}", $_SESSION['username'] ?? 'unbekannt');

            $success_message = "Benutzer wurde erfolgreich bearbeitet.";
            header("Location: admin.php?page=manage_users");
            exit;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Benutzer verwalten</title>
    <link rel="stylesheet" href="../styles/styles-admin.css">
    <script>
        function checkPasswordStrength() {
            var passwordField = document.getElementById("new_password");
            var password = passwordField.value;
            var feedbackText = document.getElementById("password-feedback");

            // Prüfen, ob das Passwort mindestens 16 Zeichen enthält (128 Bit)
            var lengthCheck = password.length >= 16;

            // Prüfen auf Großbuchstaben
            var upperCaseCheck = /[A-Z]/.test(password);

            // Prüfen auf Kleinbuchstaben
            var lowerCaseCheck = /[a-z]/.test(password);

            // Prüfen auf Zahlen
            var numberCheck = /\d/.test(password);

            // Prüfen auf Sonderzeichen
            var specialCharCheck = /[!@#$%^&*(),.?":{}|<>]/.test(password);

            // Gesamtbewertung
            var isPasswordStrong = lengthCheck && upperCaseCheck && lowerCaseCheck && numberCheck && specialCharCheck;

            // Stärkebewertung ausgeben
            if (isPasswordStrong) {
                passwordField.style.borderColor = "green";
                feedbackText.innerText = "Passwort ist stark!";
                feedbackText.style.color = "green";
            } else {
                passwordField.style.borderColor = "red";
                feedbackText.innerText = "Passwort ist unsicher!";
                feedbackText.style.color = "red";
            }
        }

        // Funktion zum Anzeigen/Verbergen des Passworts
        function togglePasswordVisibility() {
            var passwordField = document.getElementById("new_password");
            var passwordFieldType = passwordField.type;
            if (passwordFieldType === "password") {
                passwordField.type = "text";
            } else {
                passwordField.type = "password";
            }
        }

        // Zufälliges Passwort generieren und einfügen
        function generateRandomPassword() {
            var randomPassword = "<?php echo generate_random_password(); ?>";
            document.getElementById("new_password").value = randomPassword;
            checkPasswordStrength(); // Passwortlänge überprüfen
        }
    </script>
</head>
<body>
    <div class="main-content">
        <h1>👥 Benutzer verwalten</h1>

        <?php if (isset($success_message)): ?>
            <p class="success"><?= htmlspecialchars($success_message, ENT_QUOTES, 'UTF-8') ?></p>
        <?php endif; ?>

        <h2>Benutzer <?= isset($_GET['edit_user']) ? 'bearbeiten' : 'hinzufügen' ?></h2>
        <form method="post">
            <div class="form-group">
                <label for="new_username" class="form-label">Benutzername:</label>
                <input type="text" name="new_username" id="new_username" class="form-input" value="<?= isset($edit_user) ? htmlspecialchars($edit_user['username'], ENT_QUOTES, 'UTF-8') : '' ?>" required>
            </div>

            <div class="form-group">
                <label for="new_firstname" class="form-label">Vorname:</label>
                <input type="text" name="new_firstname" id="new_firstname" class="form-input" value="<?= isset($edit_user) ? htmlspecialchars($edit_user['firstname'], ENT_QUOTES, 'UTF-8') : '' ?>" required>
            </div>

            <div class="form-group">
                <label for="new_lastname" class="form-label">Nachname:</label>
                <input type="text" name="new_lastname" id="new_lastname" class="form-input" value="<?= isset($edit_user) ? htmlspecialchars($edit_user['lastname'], ENT_QUOTES, 'UTF-8') : '' ?>" required>
            </div>

            <div class="form-group">
                <label for="new_email" class="form-label">E-Mail:</label>
                <input type="email" name="new_email" id="new_email" class="form-input" value="<?= isset($edit_user) ? htmlspecialchars($edit_user['email'], ENT_QUOTES, 'UTF-8') : '' ?>" required>
            </div>

            <div class="form-group">
                <label for="new_password" class="form-label">Passwort:</label>
                <input type="password" name="new_password" id="new_password" class="form-input" value="" oninput="checkPasswordStrength()">
                <span id="password-feedback"></span>
                <button type="button" class="toggle-password" onclick="togglePasswordVisibility()">👁️</button>
                <button type="button" class="generate-password" onclick="generateRandomPassword()">Zufalls-Passwort</button>
            </div>

            <div class="form-group">
                <button type="submit" name="edit_user" class="upload-btn">
					<?= isset($edit_user) ? 'Änderungen speichern' : 'Benutzer hinzufügen' ?>
				</button>
            </div>
        </form>

        <h2>Benutzerliste:</h2>
        <table>
            <thead>
                <tr>
                    <th>Benutzername</th>
                    <th>Vorname</th>
                    <th>Nachname</th>
                    <th>E-Mail</th>
                    <th>Aktionen</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $index => $admin): ?>
                <tr>
                    <td><?= htmlspecialchars($admin['username'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($admin['firstname'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($admin['lastname'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td><?= htmlspecialchars($admin['email'], ENT_QUOTES, 'UTF-8') ?></td>
                    <td>
                        <a href="?page=manage_users&edit_user=<?= $index ?>">Bearbeiten</a>
                        <a href="?page=manage_users&delete_user=<?= $index ?>" onclick="return confirm('Möchten Sie diesen Benutzer wirklich löschen?')">Löschen</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>
