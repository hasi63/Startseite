<?php
// /menu/settings.php

// Session starten
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$upload_dir = __DIR__ . '/../uploads/';
$logo_file = $upload_dir . 'logo.png';
$favicon_file = $upload_dir . 'favicon.ico';
$changeLogPath = __DIR__ . '/../data/change_log.json'; // Pfad zur Änderungsprotokoll-Datei

// Funktion: Änderungen in die JSON-Datei schreiben
function logChange($filePath, $description, $username) {
    $currentData = [];
    if (file_exists($filePath)) {
        $jsonData = file_get_contents($filePath);
        $currentData = json_decode($jsonData, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log("Fehler in JSON-Datei: " . json_last_error_msg());
            $currentData = []; // Fallback bei fehlerhaftem JSON
        }
    }

    $newChange = [
        'change_date' => date('Y-m-d H:i:s'),
        'description' => $description,
        'username' => $username
    ];
    $currentData[] = $newChange;

    if (file_put_contents($filePath, json_encode($currentData, JSON_PRETTY_PRINT)) === false) {
        error_log("Fehler beim Schreiben in die Datei: $filePath");
    }
}

// Logo und Favicon hochladen
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }

    // Logo hochladen
    if (isset($_FILES['logo']) && !empty($_FILES['logo']['tmp_name'])) {
        $allowed_types = ['image/png']; // Nur PNG-Dateien erlauben
        if (in_array(mime_content_type($_FILES['logo']['tmp_name']), $allowed_types)) {
            move_uploaded_file($_FILES['logo']['tmp_name'], $logo_file);
            logChange($changeLogPath, 'Logo aktualisiert', $_SESSION['username'] ?? 'unbekannt');
        } else {
            die("Ungültiger Dateityp für das Logo.");
        }
    }

    // Favicon hochladen
    if (isset($_FILES['favicon']) && !empty($_FILES['favicon']['tmp_name'])) {
        $allowed_types = ['image/x-icon']; // Nur ICO-Dateien erlauben
        if (in_array(mime_content_type($_FILES['favicon']['tmp_name']), $allowed_types)) {
            move_uploaded_file($_FILES['favicon']['tmp_name'], $favicon_file);
            logChange($changeLogPath, 'Favicon aktualisiert', $_SESSION['username'] ?? 'unbekannt');
        } else {
            die("Ungültiger Dateityp für das Favicon.");
        }
    }
}
?>
<!DOCTYPE html>
<html lang="de">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logo & Favicon ändern</title>
    <link rel="stylesheet" href="../styles-admin.css">
</head>
<body>
    <div class="settings-container">
        <h1>⚙️ Logo & Favicon ändern</h1>
        <form method="post" enctype="multipart/form-data" class="upload-form">
            <div class="form-group">
                <label for="logo">Neues Logo hochladen:</label>
                <input type="file" name="logo" id="logo" accept="image/png">
            </div>
            <div class="form-group">
                <label for="favicon">Neues Favicon hochladen:</label>
                <input type="file" name="favicon" id="favicon" accept="image/x-icon">
            </div>
            <button type="submit">Hochladen</button>
        </form>
        <div class="preview-container">
            <div class="preview-item">
                <h2>Aktuelles Logo:</h2>
                <?php if (file_exists($logo_file)): ?>
                    <img src="../uploads/logo.png" alt="Logo">
                <?php else: ?>
                    <p>Kein Logo hochgeladen.</p>
                <?php endif; ?>
            </div>
            <div class="preview-item">
                <h2>Aktuelles Favicon:</h2>
                <?php if (file_exists($favicon_file)): ?>
                    <img src="../uploads/favicon.ico" alt="Favicon">
                <?php else: ?>
                    <p>Kein Favicon hochgeladen.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>